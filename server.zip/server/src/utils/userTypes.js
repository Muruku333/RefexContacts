module.exports = {
	SuperAdmin: "Admin",
	Admin: "CHRO",
	User: "HR",
};
